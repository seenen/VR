# Unity-Obj-Loader
在Unity3D中使用脚本来解析和加载.obj文件即.mtl文件的一个尝试和研究

相关链接：[解析OBJ模型并将其加载到Unity3D场景中](http://qinyuanpei.com/2015/11/15/deep-learning-of-3d-model-file-format-of-obj/)

Todo：
* 1、读取贴图目前依赖于Unity3D里的协程，这是个糟糕的设计
* 2、虽然材质可以单独创建，可是目前没有找到对物体进行分类的方法
